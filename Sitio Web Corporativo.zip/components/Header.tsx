import { Button } from "./ui/button";
import sixthMindLogo from "figma:asset/32a9ad93d57be6e75b8a31e6e2baeb8a8d3b37a9.png";

export function Header({ onNavigateToFoundIt }: { onNavigateToFoundIt?: () => void }) {
  return (
    <header 
      className="py-4 px-6 sticky top-0 z-50 shadow-lg backdrop-blur-md border-b"
      style={{ 
        backgroundColor: 'var(--sixth-mind-white)',
        borderBottomColor: 'var(--sixth-mind-cream-dark)'
      }}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <img 
            src={sixthMindLogo} 
            alt="Sixth Mind Logo" 
            className="h-10 w-auto"
          />
        </div>
        
        <nav className="hidden md:flex space-x-8">
          <a 
            href="#inicio" 
            className="transition-colors"
            style={{ color: 'var(--sixth-mind-text)' }}
            onMouseOver={(e) => e.target.style.color = 'var(--sixth-mind-secondary)'}
            onMouseOut={(e) => e.target.style.color = 'var(--sixth-mind-text)'}
          >
            Inicio
          </a>
          <a 
            href="#nosotros" 
            className="transition-colors"
            style={{ color: 'var(--sixth-mind-text)' }}
            onMouseOver={(e) => e.target.style.color = 'var(--sixth-mind-secondary)'}
            onMouseOut={(e) => e.target.style.color = 'var(--sixth-mind-text)'}
          >
            Nosotros
          </a>
          <a 
            href="#equipo" 
            className="transition-colors"
            style={{ color: 'var(--sixth-mind-text)' }}
            onMouseOver={(e) => e.target.style.color = 'var(--sixth-mind-secondary)'}
            onMouseOut={(e) => e.target.style.color = 'var(--sixth-mind-text)'}
          >
            Equipo
          </a>
          <a 
            href="#contacto" 
            className="transition-colors"
            style={{ color: 'var(--sixth-mind-text)' }}
            onMouseOver={(e) => e.target.style.color = 'var(--sixth-mind-secondary)'}
            onMouseOut={(e) => e.target.style.color = 'var(--sixth-mind-text)'}
          >
            Contacto
          </a>
        </nav>
        
        <Button 
          className="text-white transition-all hover:scale-105 shadow-md"
          style={{ backgroundColor: 'var(--sixth-mind-secondary)' }}
        >
          Contáctanos
        </Button>
      </div>
    </header>
  );
}