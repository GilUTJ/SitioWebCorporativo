import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { useState, useEffect } from "react";
import foundItLogo from "figma:asset/f9866f4a664ec9fc2ac079a5ff356598b98ac7db.png";

export function FoundItPage({ onBack }: { onBack: () => void }) {
  const [hoveredFeature, setHoveredFeature] = useState<number | null>(null);
  const [sparkles, setSparkles] = useState<Array<{id: number, x: number, y: number}>>([]);

  // Generate magical sparkles
  useEffect(() => {
    const generateSparkle = () => {
      const newSparkle = {
        id: Math.random(),
        x: Math.random() * 100,
        y: Math.random() * 100
      };
      setSparkles(prev => [...prev.slice(-15), newSparkle]);
    };

    const interval = setInterval(generateSparkle, 1000);
    return () => clearInterval(interval);
  }, []);

  const features = [
    {
      title: "Búsqueda Inteligente",
      description: "Algoritmos avanzados de IA que entienden el contexto y la intención de búsqueda",
      icon: "🔍",
      color: "var(--found-it-ound-blue)"
    },
    {
      title: "Resultados Instantáneos",
      description: "Encuentra lo que buscas en microsegundos con precisión absoluta",
      icon: "⚡",
      color: "var(--found-it-it-red)"
    },
    {
      title: "Interfaz Mágica",
      description: "Experiencia de usuario fluida e intuitiva que se adapta a ti",
      icon: "✨",
      color: "var(--found-it-f-dark)"
    }
  ];

  return (
    <div 
      className="min-h-screen relative overflow-hidden"
      style={{ backgroundColor: 'var(--found-it-white)' }}
    >
      {/* Magical background sparkles */}
      <div className="absolute inset-0 pointer-events-none">
        {sparkles.map((sparkle) => (
          <div
            key={sparkle.id}
            className="absolute w-1 h-1 animate-sparkle"
            style={{
              left: `${sparkle.x}%`,
              top: `${sparkle.y}%`,
              backgroundColor: Math.random() > 0.5 ? 'var(--found-it-ound-blue)' : 'var(--found-it-it-red)'
            }}
          />
        ))}
      </div>

      {/* Floating geometric shapes */}
      <div className="absolute inset-0 opacity-5">
        <div 
          className="absolute top-20 left-10 w-32 h-32 rounded-full animate-magic-float"
          style={{ backgroundColor: 'var(--found-it-ound-blue)' }}
        ></div>
        <div 
          className="absolute top-40 right-20 w-24 h-24 animate-magic-float"
          style={{ 
            backgroundColor: 'var(--found-it-it-red)', 
            clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
            animationDelay: '1s' 
          }}
        ></div>
        <div 
          className="absolute bottom-32 left-1/3 w-28 h-28 animate-magic-float"
          style={{ 
            backgroundColor: 'var(--found-it-f-dark)', 
            borderRadius: '50% 20% 50% 20%',
            animationDelay: '2s' 
          }}
        ></div>
      </div>

      {/* Header - Minimal and clean */}
      <header 
        className="py-6 px-6 backdrop-blur-md border-b border-opacity-10"
        style={{ 
          backgroundColor: 'rgba(255, 255, 255, 0.9)',
          borderBottomColor: 'var(--found-it-f-dark)'
        }}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img 
              src={foundItLogo} 
              alt="Found-It Logo" 
              className="h-8 w-auto animate-magic-float"
            />
            <div className="text-3xl">
              <span style={{ color: 'var(--found-it-f-dark)' }}>F</span>
              <span style={{ color: 'var(--found-it-ound-blue)' }}>ound</span>
              <span style={{ color: 'var(--found-it-it-red)' }}>-IT</span>
            </div>
          </div>
          
          <Button 
            onClick={onBack}
            className="border-2 transition-all hover:scale-105 shadow-lg backdrop-blur-sm"
            variant="outline"
            style={{ 
              borderColor: 'var(--sixth-mind-secondary)',
              color: 'var(--sixth-mind-secondary)',
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }}
          >
            ← Volver a Sixth Mind
          </Button>
        </div>
      </header>

      {/* Hero Section - Magical and minimalist */}
      <section className="py-32 px-6 text-center relative">
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="animate-fade-in-up">
            <h1 className="text-8xl mb-8 animate-found-it-glow">
              <span 
                className="magic-text-shadow"
                style={{ color: 'var(--found-it-f-dark)' }}
              >
                F
              </span>
              <span 
                className="magic-text-shadow"
                style={{ color: 'var(--found-it-ound-blue)' }}
              >
                ound
              </span>
              <span 
                className="magic-text-shadow"
                style={{ color: 'var(--found-it-it-red)' }}
              >
                -IT
              </span>
            </h1>
            
            <h2 
              className="text-2xl mb-6 animate-slide-in-left"
              style={{ color: 'var(--found-it-software-black)' }}
            >
              Software
            </h2>
            
            <p 
              className="text-xl max-w-2xl mx-auto mb-16 leading-relaxed animate-slide-in-right"
              style={{ color: 'var(--found-it-software-black)', opacity: 0.8 }}
            >
              La revolución en búsquedas inteligentes. 
              Encuentra exactamente lo que necesitas con la magia de la tecnología avanzada.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Button 
                className="px-12 py-6 text-lg text-white transition-all hover:scale-110 animate-found-it-glow shadow-2xl"
                style={{ backgroundColor: 'var(--found-it-ound-blue)' }}
              >
                🚀 Explorar Demo
              </Button>
              <Button 
                variant="outline" 
                className="px-12 py-6 text-lg border-2 transition-all hover:scale-110 shadow-lg"
                style={{ 
                  borderColor: 'var(--found-it-it-red)', 
                  color: 'var(--found-it-it-red)',
                  backgroundColor: 'rgba(255, 255, 255, 0.8)'
                }}
              >
                ✨ Ver Magia
              </Button>
            </div>
          </div>
        </div>

        {/* Floating search bar - Interactive element */}
        <div className="mt-20 max-w-2xl mx-auto">
          <div 
            className="relative p-8 rounded-3xl shadow-2xl backdrop-blur-lg border animate-magic-float"
            style={{ 
              background: `linear-gradient(135deg, 
                rgba(255,255,255,0.9) 0%, 
                rgba(0,0,255,0.05) 50%, 
                rgba(255,255,255,0.9) 100%)`,
              borderColor: 'var(--found-it-ound-blue)'
            }}
          >
            <div className="flex items-center space-x-4">
              <div 
                className="w-12 h-12 rounded-full flex items-center justify-center text-xl animate-glow"
                style={{ backgroundColor: 'var(--found-it-ound-blue)' }}
              >
                🔍
              </div>
              <div className="flex-1">
                <input 
                  type="text" 
                  placeholder="Busca cualquier cosa..."
                  className="w-full p-4 text-lg border-0 bg-transparent outline-none"
                  style={{ color: 'var(--found-it-software-black)' }}
                />
              </div>
              <Button 
                className="text-white px-8 py-4"
                style={{ backgroundColor: 'var(--found-it-it-red)' }}
              >
                Buscar
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - Clean and magical */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 
              className="text-5xl mb-6 animate-fade-in-up"
              style={{ color: 'var(--found-it-software-black)' }}
            >
              Características Mágicas
            </h2>
            <div 
              className="w-32 h-1 mx-auto mb-8"
              style={{ 
                background: `linear-gradient(90deg, 
                  var(--found-it-f-dark) 0%, 
                  var(--found-it-ound-blue) 50%, 
                  var(--found-it-it-red) 100%)`
              }}
            ></div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group perspective-1000"
                onMouseEnter={() => setHoveredFeature(index)}
                onMouseLeave={() => setHoveredFeature(null)}
              >
                <Card 
                  className={`
                    relative h-80 cursor-pointer transition-all duration-700 transform-gpu
                    border-0 shadow-xl backdrop-blur-sm overflow-hidden
                    ${hoveredFeature === index ? 'scale-110 rotate-y-12' : 'hover:scale-105'}
                  `}
                  style={{ 
                    background: hoveredFeature === index 
                      ? `linear-gradient(135deg, rgba(255,255,255,0.95) 0%, ${feature.color}10 100%)`
                      : 'rgba(255,255,255,0.9)',
                    borderLeft: `4px solid ${feature.color}`,
                    boxShadow: hoveredFeature === index 
                      ? `0 25px 50px ${feature.color}30` 
                      : '0 10px 30px rgba(0,0,0,0.1)'
                  }}
                >
                  {/* Magical glow effect */}
                  <div 
                    className={`
                      absolute inset-0 rounded-lg transition-opacity duration-500
                      ${hoveredFeature === index ? 'opacity-30' : 'opacity-0'}
                    `}
                    style={{ 
                      background: `radial-gradient(circle at center, ${feature.color}20, transparent 70%)`
                    }}
                  />
                  
                  <CardContent className="p-8 h-full flex flex-col justify-center text-center relative z-10">
                    {/* Floating magical icon */}
                    <div 
                      className={`
                        text-6xl mb-8 transition-all duration-500 transform
                        ${hoveredFeature === index ? 'scale-125 animate-magic-float' : ''}
                      `}
                    >
                      {feature.icon}
                    </div>
                    
                    {/* Title with magical text */}
                    <h3 
                      className="text-2xl mb-6 transition-all duration-500"
                      style={{ 
                        color: hoveredFeature === index ? feature.color : 'var(--found-it-software-black)',
                        textShadow: hoveredFeature === index ? `0 0 20px ${feature.color}50` : 'none'
                      }}
                    >
                      {feature.title}
                    </h3>
                    
                    {/* Description */}
                    <p 
                      className="leading-relaxed transition-all duration-500"
                      style={{ 
                        color: 'var(--found-it-software-black)', 
                        opacity: hoveredFeature === index ? 1 : 0.7 
                      }}
                    >
                      {feature.description}
                    </p>
                    
                    {/* Interactive magical particles */}
                    {hoveredFeature === index && (
                      <div className="absolute inset-0 pointer-events-none">
                        {[...Array(6)].map((_, i) => (
                          <div
                            key={i}
                            className="absolute w-2 h-2 rounded-full animate-sparkle"
                            style={{
                              backgroundColor: feature.color,
                              left: `${20 + i * 12}%`,
                              top: `${30 + (i % 2) * 25}%`,
                              animationDelay: `${i * 0.2}s`,
                              opacity: 0.8
                            }}
                          />
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action - Minimal and powerful */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div 
            className="p-16 rounded-3xl shadow-2xl backdrop-blur-lg border animate-fade-in-up"
            style={{ 
              background: `linear-gradient(135deg, 
                rgba(255,255,255,0.95) 0%, 
                rgba(0,0,255,0.05) 30%,
                rgba(255,0,0,0.05) 70%,
                rgba(255,255,255,0.95) 100%)`,
              borderColor: 'var(--found-it-ound-blue)'
            }}
          >
            <h3 
              className="text-4xl mb-8"
              style={{ color: 'var(--found-it-software-black)' }}
            >
              ¿Listo para encontrar todo?
            </h3>
            <p 
              className="text-xl mb-12 opacity-80"
              style={{ color: 'var(--found-it-software-black)' }}
            >
              Únete a la revolución de búsquedas inteligentes y descubre el poder de Found-IT
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Button 
                className="px-10 py-4 text-lg text-white transition-all hover:scale-110 shadow-xl"
                style={{ backgroundColor: 'var(--found-it-it-red)' }}
              >
                🎯 Comenzar Ahora
              </Button>
              <Button 
                onClick={onBack}
                variant="outline" 
                className="px-10 py-4 text-lg border-2 transition-all hover:scale-110"
                style={{ 
                  borderColor: 'var(--sixth-mind-secondary)', 
                  color: 'var(--sixth-mind-secondary)',
                  backgroundColor: 'rgba(255,255,255,0.8)'
                }}
              >
                🏠 Volver a Sixth Mind
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer - Minimal branding */}
      <footer 
        className="py-12 px-6 text-center border-t border-opacity-10"
        style={{ 
          backgroundColor: 'rgba(255,255,255,0.9)',
          borderTopColor: 'var(--found-it-f-dark)'
        }}
      >
        <div className="flex items-center justify-center space-x-4 mb-6">
          <img 
            src={foundItLogo} 
            alt="Found-It Logo" 
            className="h-6 w-auto"
          />
          <div className="text-2xl">
            <span style={{ color: 'var(--found-it-f-dark)' }}>F</span>
            <span style={{ color: 'var(--found-it-ound-blue)' }}>ound</span>
            <span style={{ color: 'var(--found-it-it-red)' }}>-IT</span>
          </div>
        </div>
        <p 
          className="text-sm opacity-70"
          style={{ color: 'var(--found-it-software-black)' }}
        >
          Desarrollado con ❤️ por <span style={{ color: 'var(--sixth-mind-secondary)' }}>Sixth Mind</span>
        </p>
      </footer>
    </div>
  );
}